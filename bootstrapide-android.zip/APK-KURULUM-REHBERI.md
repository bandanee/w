# Bootstrap IDE — APK'yi telefona kurma

Bu paket bir **Android projesidir**; APK bir derleyici ile üretilir (tarayıcı APK derleyemez).

## A) Kurulum gerektirmeyen bulut derleme (AppsGeyser mantığı)
1. Bu klasörü bir GitHub deposu olarak gönder (New repository → upload).
2. Depoda **Actions** sekmesi otomatik `android` iş akışını çalıştırır (yoksa .github/workflows ekleyin).
3. İş akışı bittiğinde **Artifacts → android-apk** indir = hazır .apk.
   (İş akışı pakette hazır: `.github/workflows/build-apk.yml`. Web'de gizli klasörü göremiyorsan **Add file → New file** ile aynı yola elle ekle.)

## B) Tek seferlik yerel derleme
Android Studio kur → bu klasörü aç → **Build ▸ Build APK(s)** → `app-debug.apk`.

## C) APK'yi telefona yükleme
1. apk dosyasını telefona kopyala.
2. Ayarlar → Güvenlik → **Bilinmeyen kaynaklar** izin ver.
3. apk dosyasına dokun → **Yine de yükle**.
