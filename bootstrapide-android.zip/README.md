# Bootstrap IDE — Saf Android WebView uygulaması

Capacitor/Cordova olmadan, **doğrudan Gradle ile APK** üreten eksiksiz proje iskeleti.
Web dosyaların `app/src/main/assets/www/` içine yerleştirildi.

## APK derleme
**A) Android Studio ile**
1. Bu klasörü *Open* ile aç (Gradle wrapper'ı otomatik oluşturur).
2. *Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)*
3. Çıktı: `app/build/outputs/apk/debug/app-debug.apk`

**B) Komut satırı ile** (JDK 17 + Android SDK gerekir)
```bash
gradle wrapper --gradle-version 8.7   # bir kez
./gradlew assembleDebug               # imzasız debug APK
./gradlew assembleRelease
```

## İmzalama (dağıtım için)
```bash
keytool -genkey -v -keystore my.keystore -alias BootstrapIDE -keyalg RSA -keysize 2048 -validity 10000
```
`app/build.gradle` içine `signingConfigs` bloğu ekle → `assembleRelease`.

## Uygulama adı / ikon
- Ad: `app/src/main/res/values/strings.xml`
- İkon: `app/src/main/res/mipmap-*/ic_launcher.png` (512 px kaynağı ayrıca eklendi)
